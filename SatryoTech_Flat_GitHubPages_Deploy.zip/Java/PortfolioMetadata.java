/**
 * Metadata model for the Satryo Tech portfolio.
 * This file is a standalone Java example and is not required by the website runtime.
 */
public class PortfolioMetadata {
    public static final String OWNER = "Aditya Dwi Satryo";
    public static final String BRAND = "Satryo Tech";
    public static final String GITHUB = "https://github.com/satryotech";
    public static final String PORTFOLIO_TITLE = "Information Technology Enthusiast";

    public static void main(String[] args) {
        System.out.println(PORTFOLIO_TITLE + " — " + OWNER);
        System.out.println("GitHub: " + GITHUB);
    }
}
