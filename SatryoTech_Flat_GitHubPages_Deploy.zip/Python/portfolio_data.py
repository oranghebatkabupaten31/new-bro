"""Structured portfolio metadata example for Satryo Tech.

This file is a separate Python reference module; the static website does not
need Python installed to run.
"""

PROFILE = {
    "name": "Aditya Dwi Satryo",
    "brand": "Satryo Tech",
    "title": "Information Technology Enthusiast",
    "github": "https://github.com/satryotech",
    "interests": [
        "Network Engineering",
        "Junior Cybersecurity",
        "IT Support",
        "Software Engineering",
        "Hardware Engineering",
        "Front-End Development",
    ],
}

if __name__ == "__main__":
    print(f"{PROFILE['name']} | {PROFILE['title']}")
    print("Focus:", ", ".join(PROFILE["interests"]))
